package ch.idsia.blip.core.learn.missing;


import ch.idsia.blip.core.learn.scorer.IndependenceScorer;


public class MissingIndependenceScorer extends IndependenceScorer {}
