package ch.idsia.blip.core.inference.ve.samiam;


class Samiam {/*

     private final BeliefNetwork net;

     public Samiam(String t) throws Exception {
     net = NetworkIO.readHuginNet(getReader(t));
     }

     public void query(String var5) {
     HuginEngineGenerator gen = new HuginEngineGenerator();

     InferenceEngine eng = gen.manufactureInferenceEngine(net);

     EvidenceController var9 = net.getEvidenceController();
     var9.addPriorityEvidenceChangeListener(eng);
     // var9.setObservations(var4);

     }

     */}
