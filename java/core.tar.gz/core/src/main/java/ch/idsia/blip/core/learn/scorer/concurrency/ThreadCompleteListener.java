package ch.idsia.blip.core.learn.scorer.concurrency;


public interface ThreadCompleteListener {
    void notifyOfThreadComplete();
}
