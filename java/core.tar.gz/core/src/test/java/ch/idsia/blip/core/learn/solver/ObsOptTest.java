package ch.idsia.blip.core.learn.solver;


import ch.idsia.TheTest;
import org.junit.Test;


public class ObsOptTest extends TheTest {

    public ObsOptTest() {
        basePath += "asobs/opt/";
    }

    @Test
    public void test() throws Exception {}
}
